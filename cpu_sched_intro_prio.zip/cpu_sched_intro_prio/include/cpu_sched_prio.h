#ifndef CPU_SCHED_PRIO_H
#define CPU_SCHED_PRIO_H

#endif // CPU_SCHED_PRIO_H
